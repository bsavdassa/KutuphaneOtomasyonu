﻿namespace KutuphaneTakip.Formlar.EmanetKitap
{
    partial class EmanetKitap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnYenile = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnEkle = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblKayitliKitapSayisi = new System.Windows.Forms.Label();
            this.lblKitapSayisi = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbTelefon = new System.Windows.Forms.ComboBox();
            this.cmbSoyad = new System.Windows.Forms.ComboBox();
            this.cmbAd = new System.Windows.Forms.ComboBox();
            this.cmbTcNo = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbYayinEvi = new System.Windows.Forms.ComboBox();
            this.cmbKitapYazari = new System.Windows.Forms.ComboBox();
            this.cmbKitapAdi = new System.Windows.Forms.ComboBox();
            this.cmbBarkodNo = new System.Windows.Forms.ComboBox();
            this.dtpIadeTarihi = new System.Windows.Forms.DateTimePicker();
            this.dtpTeslimTarihi = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.numSayfaSayisi = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.numKitapSayisi = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbKitapSayisi = new System.Windows.Forms.ComboBox();
            this.cmbSayfaSayisi = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSayfaSayisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKitapSayisi)).BeginInit();
            this.SuspendLayout();
            // 
            // btnYenile
            // 
            this.btnYenile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYenile.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnYenile.Location = new System.Drawing.Point(539, 347);
            this.btnYenile.Name = "btnYenile";
            this.btnYenile.Size = new System.Drawing.Size(249, 40);
            this.btnYenile.TabIndex = 80;
            this.btnYenile.Text = "Yenile";
            this.btnYenile.UseVisualStyleBackColor = true;
            this.btnYenile.Click += new System.EventHandler(this.btnYenile_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 29);
            this.panel1.TabIndex = 57;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.IndianRed;
            this.button9.Location = new System.Drawing.Point(772, 0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(29, 29);
            this.button9.TabIndex = 1;
            this.button9.Text = "X";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(191, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Emanet Kitap - Sepete Ekleme İşlemleri";
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuncelle.ForeColor = System.Drawing.Color.Turquoise;
            this.btnGuncelle.Location = new System.Drawing.Point(540, 302);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(249, 40);
            this.btnGuncelle.TabIndex = 79;
            this.btnGuncelle.Text = "Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = true;
            // 
            // btnSil
            // 
            this.btnSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSil.ForeColor = System.Drawing.Color.Red;
            this.btnSil.Location = new System.Drawing.Point(283, 347);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(123, 40);
            this.btnSil.TabIndex = 78;
            this.btnSil.Text = "Sepetten Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(285, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(504, 228);
            this.dataGridView1.TabIndex = 58;
            this.dataGridView1.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEnter);
            // 
            // btnEkle
            // 
            this.btnEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEkle.ForeColor = System.Drawing.Color.LawnGreen;
            this.btnEkle.Location = new System.Drawing.Point(285, 302);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(123, 40);
            this.btnEkle.TabIndex = 77;
            this.btnEkle.Text = "Sepete Ekle";
            this.btnEkle.UseVisualStyleBackColor = true;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(62, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 65;
            this.label6.Text = "TC No:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(63, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 67;
            this.label9.Text = "Soyad:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(80, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 66;
            this.label7.Text = "Ad:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(57, 102);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 13);
            this.label11.TabIndex = 71;
            this.label11.Text = "Telefon:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(424, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 82;
            this.label1.Text = "Kayıtlı Kitap Sayısı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(582, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 13);
            this.label2.TabIndex = 82;
            this.label2.Text = "Sepetteki Kitap Sayısı:";
            // 
            // lblKayitliKitapSayisi
            // 
            this.lblKayitliKitapSayisi.AutoSize = true;
            this.lblKayitliKitapSayisi.ForeColor = System.Drawing.Color.IndianRed;
            this.lblKayitliKitapSayisi.Location = new System.Drawing.Point(524, 39);
            this.lblKayitliKitapSayisi.Name = "lblKayitliKitapSayisi";
            this.lblKayitliKitapSayisi.Size = new System.Drawing.Size(13, 13);
            this.lblKayitliKitapSayisi.TabIndex = 83;
            this.lblKayitliKitapSayisi.Text = "0";
            // 
            // lblKitapSayisi
            // 
            this.lblKitapSayisi.AutoSize = true;
            this.lblKitapSayisi.ForeColor = System.Drawing.Color.IndianRed;
            this.lblKitapSayisi.Location = new System.Drawing.Point(700, 39);
            this.lblKitapSayisi.Name = "lblKitapSayisi";
            this.lblKitapSayisi.Size = new System.Drawing.Size(13, 13);
            this.lblKitapSayisi.TabIndex = 83;
            this.lblKitapSayisi.Text = "0";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbTelefon);
            this.groupBox1.Controls.Add(this.cmbSoyad);
            this.groupBox1.Controls.Add(this.cmbAd);
            this.groupBox1.Controls.Add(this.cmbTcNo);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Location = new System.Drawing.Point(12, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(267, 124);
            this.groupBox1.TabIndex = 84;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Müşteri";
            // 
            // cmbTelefon
            // 
            this.cmbTelefon.BackColor = System.Drawing.Color.IndianRed;
            this.cmbTelefon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTelefon.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbTelefon.FormattingEnabled = true;
            this.cmbTelefon.Location = new System.Drawing.Point(109, 95);
            this.cmbTelefon.Name = "cmbTelefon";
            this.cmbTelefon.Size = new System.Drawing.Size(144, 21);
            this.cmbTelefon.TabIndex = 72;
            this.cmbTelefon.Tag = "telefon";
            this.cmbTelefon.SelectedIndexChanged += new System.EventHandler(this.panelUye_SelectedIndexChanged);
            // 
            // cmbSoyad
            // 
            this.cmbSoyad.BackColor = System.Drawing.Color.IndianRed;
            this.cmbSoyad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSoyad.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSoyad.FormattingEnabled = true;
            this.cmbSoyad.Location = new System.Drawing.Point(109, 69);
            this.cmbSoyad.Name = "cmbSoyad";
            this.cmbSoyad.Size = new System.Drawing.Size(144, 21);
            this.cmbSoyad.TabIndex = 72;
            this.cmbSoyad.Tag = "soyad";
            this.cmbSoyad.SelectedIndexChanged += new System.EventHandler(this.panelUye_SelectedIndexChanged);
            // 
            // cmbAd
            // 
            this.cmbAd.BackColor = System.Drawing.Color.IndianRed;
            this.cmbAd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbAd.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbAd.FormattingEnabled = true;
            this.cmbAd.Location = new System.Drawing.Point(109, 43);
            this.cmbAd.Name = "cmbAd";
            this.cmbAd.Size = new System.Drawing.Size(144, 21);
            this.cmbAd.TabIndex = 72;
            this.cmbAd.Tag = "ad";
            this.cmbAd.SelectedIndexChanged += new System.EventHandler(this.panelUye_SelectedIndexChanged);
            // 
            // cmbTcNo
            // 
            this.cmbTcNo.BackColor = System.Drawing.Color.IndianRed;
            this.cmbTcNo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTcNo.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbTcNo.FormattingEnabled = true;
            this.cmbTcNo.Location = new System.Drawing.Point(109, 17);
            this.cmbTcNo.Name = "cmbTcNo";
            this.cmbTcNo.Size = new System.Drawing.Size(144, 21);
            this.cmbTcNo.TabIndex = 72;
            this.cmbTcNo.Tag = "tcNo";
            this.cmbTcNo.SelectedIndexChanged += new System.EventHandler(this.panelUye_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbYayinEvi);
            this.groupBox2.Controls.Add(this.cmbKitapYazari);
            this.groupBox2.Controls.Add(this.cmbKitapAdi);
            this.groupBox2.Controls.Add(this.cmbBarkodNo);
            this.groupBox2.Controls.Add(this.dtpIadeTarihi);
            this.groupBox2.Controls.Add(this.dtpTeslimTarihi);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.numSayfaSayisi);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.numKitapSayisi);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Location = new System.Drawing.Point(12, 168);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(267, 219);
            this.groupBox2.TabIndex = 85;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kitap Bilgileri";
            // 
            // cmbYayinEvi
            // 
            this.cmbYayinEvi.BackColor = System.Drawing.Color.IndianRed;
            this.cmbYayinEvi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbYayinEvi.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbYayinEvi.FormattingEnabled = true;
            this.cmbYayinEvi.Location = new System.Drawing.Point(107, 92);
            this.cmbYayinEvi.Name = "cmbYayinEvi";
            this.cmbYayinEvi.Size = new System.Drawing.Size(144, 21);
            this.cmbYayinEvi.TabIndex = 72;
            this.cmbYayinEvi.Tag = "kitapYayinEvi";
            this.cmbYayinEvi.SelectedIndexChanged += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // cmbKitapYazari
            // 
            this.cmbKitapYazari.BackColor = System.Drawing.Color.IndianRed;
            this.cmbKitapYazari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbKitapYazari.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbKitapYazari.FormattingEnabled = true;
            this.cmbKitapYazari.Location = new System.Drawing.Point(107, 67);
            this.cmbKitapYazari.Name = "cmbKitapYazari";
            this.cmbKitapYazari.Size = new System.Drawing.Size(144, 21);
            this.cmbKitapYazari.TabIndex = 72;
            this.cmbKitapYazari.Tag = "kitapYazari";
            this.cmbKitapYazari.SelectedIndexChanged += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // cmbKitapAdi
            // 
            this.cmbKitapAdi.BackColor = System.Drawing.Color.IndianRed;
            this.cmbKitapAdi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbKitapAdi.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbKitapAdi.FormattingEnabled = true;
            this.cmbKitapAdi.Location = new System.Drawing.Point(107, 42);
            this.cmbKitapAdi.Name = "cmbKitapAdi";
            this.cmbKitapAdi.Size = new System.Drawing.Size(144, 21);
            this.cmbKitapAdi.TabIndex = 72;
            this.cmbKitapAdi.Tag = "kitapAdi";
            this.cmbKitapAdi.SelectedIndexChanged += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // cmbBarkodNo
            // 
            this.cmbBarkodNo.BackColor = System.Drawing.Color.IndianRed;
            this.cmbBarkodNo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbBarkodNo.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbBarkodNo.FormattingEnabled = true;
            this.cmbBarkodNo.Location = new System.Drawing.Point(107, 17);
            this.cmbBarkodNo.Name = "cmbBarkodNo";
            this.cmbBarkodNo.Size = new System.Drawing.Size(144, 21);
            this.cmbBarkodNo.TabIndex = 72;
            this.cmbBarkodNo.Tag = "barkodNo";
            this.cmbBarkodNo.SelectedIndexChanged += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // dtpIadeTarihi
            // 
            this.dtpIadeTarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpIadeTarihi.Location = new System.Drawing.Point(107, 191);
            this.dtpIadeTarihi.Name = "dtpIadeTarihi";
            this.dtpIadeTarihi.Size = new System.Drawing.Size(146, 20);
            this.dtpIadeTarihi.TabIndex = 98;
            this.dtpIadeTarihi.ValueChanged += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // dtpTeslimTarihi
            // 
            this.dtpTeslimTarihi.CalendarMonthBackground = System.Drawing.Color.IndianRed;
            this.dtpTeslimTarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTeslimTarihi.Location = new System.Drawing.Point(107, 168);
            this.dtpTeslimTarihi.Name = "dtpTeslimTarihi";
            this.dtpTeslimTarihi.Size = new System.Drawing.Size(146, 20);
            this.dtpTeslimTarihi.TabIndex = 98;
            this.dtpTeslimTarihi.ValueChanged += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(3, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 13);
            this.label8.TabIndex = 90;
            this.label8.Text = "Kitap Barkod No:";
            // 
            // numSayfaSayisi
            // 
            this.numSayfaSayisi.BackColor = System.Drawing.Color.IndianRed;
            this.numSayfaSayisi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numSayfaSayisi.ForeColor = System.Drawing.SystemColors.Window;
            this.numSayfaSayisi.Location = new System.Drawing.Point(107, 119);
            this.numSayfaSayisi.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numSayfaSayisi.Name = "numSayfaSayisi";
            this.numSayfaSayisi.Size = new System.Drawing.Size(146, 20);
            this.numSayfaSayisi.TabIndex = 97;
            this.numSayfaSayisi.Click += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(37, 95);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 13);
            this.label14.TabIndex = 94;
            this.label14.Text = "Yayın Evi:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(24, 120);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 13);
            this.label13.TabIndex = 93;
            this.label13.Text = "Sayfa Sayısı:";
            // 
            // numKitapSayisi
            // 
            this.numKitapSayisi.BackColor = System.Drawing.Color.IndianRed;
            this.numKitapSayisi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numKitapSayisi.ForeColor = System.Drawing.SystemColors.Window;
            this.numKitapSayisi.Location = new System.Drawing.Point(107, 144);
            this.numKitapSayisi.Name = "numKitapSayisi";
            this.numKitapSayisi.Size = new System.Drawing.Size(146, 20);
            this.numKitapSayisi.TabIndex = 96;
            this.numKitapSayisi.Click += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Location = new System.Drawing.Point(52, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 92;
            this.label12.Text = "Yazarı:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(39, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 91;
            this.label10.Text = "Kitap Adı:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.Control;
            this.label17.Location = new System.Drawing.Point(31, 193);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 13);
            this.label17.TabIndex = 95;
            this.label17.Text = "Iade Tarihi:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.Control;
            this.label15.Location = new System.Drawing.Point(22, 169);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 13);
            this.label15.TabIndex = 95;
            this.label15.Text = "Teslim Tarihi:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.Control;
            this.label16.Location = new System.Drawing.Point(27, 145);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 95;
            this.label16.Text = "Kitap Sayısı:";
            // 
            // cmbKitapSayisi
            // 
            this.cmbKitapSayisi.BackColor = System.Drawing.Color.IndianRed;
            this.cmbKitapSayisi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbKitapSayisi.FormattingEnabled = true;
            this.cmbKitapSayisi.Location = new System.Drawing.Point(728, 416);
            this.cmbKitapSayisi.Name = "cmbKitapSayisi";
            this.cmbKitapSayisi.Size = new System.Drawing.Size(49, 21);
            this.cmbKitapSayisi.TabIndex = 72;
            this.cmbKitapSayisi.TabStop = false;
            this.cmbKitapSayisi.Tag = "kitapStokSayisi";
            this.cmbKitapSayisi.Visible = false;
            this.cmbKitapSayisi.SelectedIndexChanged += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // cmbSayfaSayisi
            // 
            this.cmbSayfaSayisi.BackColor = System.Drawing.Color.IndianRed;
            this.cmbSayfaSayisi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSayfaSayisi.FormattingEnabled = true;
            this.cmbSayfaSayisi.Location = new System.Drawing.Point(673, 416);
            this.cmbSayfaSayisi.Name = "cmbSayfaSayisi";
            this.cmbSayfaSayisi.Size = new System.Drawing.Size(49, 21);
            this.cmbSayfaSayisi.TabIndex = 72;
            this.cmbSayfaSayisi.TabStop = false;
            this.cmbSayfaSayisi.Tag = "kitapSayfaSayisi";
            this.cmbSayfaSayisi.Visible = false;
            this.cmbSayfaSayisi.SelectedIndexChanged += new System.EventHandler(this.panelKitap_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.LawnGreen;
            this.button1.Location = new System.Drawing.Point(412, 302);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 40);
            this.button1.TabIndex = 77;
            this.button1.Text = "Sepeti E.K\'ya Aktar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.DarkOrange;
            this.button2.Location = new System.Drawing.Point(412, 347);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 40);
            this.button2.TabIndex = 78;
            this.button2.Text = "E.K Görüntüle";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // EmanetKitap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(800, 402);
            this.Controls.Add(this.cmbSayfaSayisi);
            this.Controls.Add(this.cmbKitapSayisi);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblKitapSayisi);
            this.Controls.Add(this.lblKayitliKitapSayisi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnYenile);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnGuncelle);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnEkle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EmanetKitap";
            this.Text = "EmanetKitap";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSayfaSayisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKitapSayisi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnYenile;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnGuncelle;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblKayitliKitapSayisi;
        private System.Windows.Forms.Label lblKitapSayisi;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numSayfaSayisi;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown numKitapSayisi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dtpTeslimTarihi;
        private System.Windows.Forms.DateTimePicker dtpIadeTarihi;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbTelefon;
        private System.Windows.Forms.ComboBox cmbSoyad;
        private System.Windows.Forms.ComboBox cmbAd;
        private System.Windows.Forms.ComboBox cmbTcNo;
        private System.Windows.Forms.ComboBox cmbYayinEvi;
        private System.Windows.Forms.ComboBox cmbKitapYazari;
        private System.Windows.Forms.ComboBox cmbKitapAdi;
        private System.Windows.Forms.ComboBox cmbBarkodNo;
        private System.Windows.Forms.ComboBox cmbKitapSayisi;
        private System.Windows.Forms.ComboBox cmbSayfaSayisi;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}